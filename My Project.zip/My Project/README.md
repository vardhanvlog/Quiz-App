# Javascript Quiz App

- Questions are dynamically generated using objects constructor
- Login/Logout System using LocalStorage
- Random questionss are asked everytime
- Next button is disabled by default in every question - you must select any option to enable it
- Shows scored percentage + correct answer with good UI at the end
- After completing quiz - your score is saved in LocalStorage - so when you even reload your page you get result instead of questions again
- You have 'Retake Quiz' option available at the end :)

* Worked on UI as well :p

This is made as an assignment while learning Javascript

Demo: https://ovi.github.io/quiz-app

Key: **12345**
