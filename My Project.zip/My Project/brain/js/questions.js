// Quiz Creator;
function CQuiz(que, o1, o2, o3, o4, ans, d) {
	this.question = que;
	this.opt1 = o1;
	this.opt2 = o2;
	this.opt3 = o3;
	this.opt4 = o4;
	this.answer = ans;
	this.asked = d;
}

// Question 1
var q1 = new CQuiz(
	'When M.S Dhoni made ODI Debut for the Indian team?',
	'2000',
	'2002',
	'2004',
	'2008',
	3,
	0
);

// Question 2
var q2 = new CQuiz(
	'Which is the largest coffee producing state of India?',
	'Karnataka',
	'Kerala',
	'Tamil Nadu',
	'Arunachal Pradesh',
	1,
	0
);

// Question 3
var q3 = new CQuiz(
	'In which state is the Elephant Falls located?',
	'Mizoram',
	'Meghalaya',
	'Manipur',
	'Orissa',
	2,
	0
);

// Question 4
var q4 = new CQuiz(
	'A computer cannot boot if it does not have the__',
	'Compiler',
	'Loader',
	'Operating system',
	'Assembler',
	3,
	0
);

// Question 5
var q5 = new CQuiz(
	'Which of the following was conferred on Mrs.Kiran Bedi?',
	'Saraswati',
	'Magsaysay',
	'Golden Globe',
	'Rani Lakshmi',
	2,
	0
);

// Question 6
var q6 = new CQuiz(
	'Who is the english physicist responsible for the "Big Bang Theory"?',
	'Albert Einstein',
	'Michael Skube',
	'George Gamow',
	'Roger Penrose',
	3,
	0
);

// Question 7
var q7 = new CQuiz(
	'Who was the first president of BCCI',
	'R.E Grant Govan',
	'Dr.Maharajkumar Sir Vijaya Ananda ',
	'Sikander Hyat Khan',
	'Anthony S.DMello',
	1,
	0
);

// Question 8
var q8 = new CQuiz(
	'How do you write "Hello World" in an alert box?',
	'alert("Hello World");',
	'msgBox("Hello World");',
	'prompt("Hello World");',
	'alertBox("Hello World");',
	1,
	0
);

// Question 9
var q9 = new CQuiz(
	'How do you create a function in JavaScript?',
	'function = myFunction()',
	'function:myFunction()',
	'function myFunction()',
	'None of the mentioned',
	3,
	0
);

// Question 10
var q10 = new CQuiz(
	'In India,Agriculture income is calculated by?',
	'Output method',
	'Input method',
	'Expenditure method',
	'Commodity flow method',
	1,
	0
);

// total question...
var totQ = [q1, q2, q3, q4, q5, q6, q7, q8, q9, q10];
